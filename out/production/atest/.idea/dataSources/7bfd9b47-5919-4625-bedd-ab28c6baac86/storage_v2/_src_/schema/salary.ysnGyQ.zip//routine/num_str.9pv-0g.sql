create
    definer = root@localhost procedure num_str(IN num int)
BEGIN
  DECLARE i INT DEFAULT 0;
  DECLARE var TINYTEXT DEFAULT '';
  IF (num > 0) THEN
	cycle : WHILE i < num DO
  	SET i = i + 1;
  	SET var = CONCAT(var, i);
  	IF i > CEILING(num / 2) THEN ITERATE cycle;
  	END IF;
  	SET var = CONCAT(var, i);
	END WHILE cycle;
	SELECT var;
  ELSE
	SELECT 'Ошибка выполнения if-условия';
  END IF;
END;

